#define _CRT_SECURE_NO_WARNINGS 1

#include "game.h"

int row = 3;
int col = 3;

int main()
{
	int choice = 0;
	char board[ROW][COL] = { 0 };
	srand((unsigned)time(0));
	while (1)
	{
		printf("1.��һ�� 0.�˳�\n");
		scanf("%d", &choice);
		switch (choice)
		{
		case 1:
			InitBoard(board, row, col);
			PrintBoard(board, row, col);
			while (1)
			{
				PlayerMove(board, row, col);
				PrintBoard(board, row, col);
				if (CheckWin(board, row, col) != 0)
				{
					break;
				}
				ComputerMove(board, row, col);
				PrintBoard(board, row, col);
				if (CheckWin(board, row, col) != 0)
				{
					break;
				}
			}
			break;
		case 0:
			exit(0);
			break;
		}
	}
	return 0;
}