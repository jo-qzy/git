#define _CRT_SECURE_NO_WARNINGS 1

#include "game.h"

int i = 0;
int j = 0;

void InitBoard(char board[ROW][COL], int row, int col)
{
	for (i = 0; i < row; i++)
	{
		for (j = 0; j < col; j++)
		{
			board[i][j] = 0;
		}
	}
}

void PrintBoard(char board[ROW][COL], int row, int col)
{
	for (i = 0; i < row; i++)
	{
		for (j = 0; j < col; j++)//��ӡÿһ�е�����
		{
			if (j == col - 1)
			{
				printf(" %c \n", board[i][j]);
				break;
			}
			printf(" %c |", board[i][j]);
		}
		if (i != row - 1)//��ӡ�����м�ĺ��ߣ�����Ѿ�������һ�У�����ӡ
		{
			for(j = 0;j<col;j++)
			{
				printf("----");
			}
			printf("\n");
		}
	}
	printf("\n");
}

void PlayerMove(char board[ROW][COL], int row, int col)
{
	printf("������Ҫ�µ�λ��:>");
	while (1)
	{
		scanf("%d%d", &i, &j);
		if ((i > row) || (j > col))
		{
			printf("�������,��������:>");
		}
		else
			break;
	}
	board[i-1][j-1] = 'X';
}

void ComputerMove(char board[ROW][COL], int row, int col)
{
	do
	{
		i = rand() % 3;
		j = rand() % 3;
	}while (board[i][j] != 0);
	board[i][j] = '0';
}

int CheckWin(char board[ROW][COL], int row, int col)
{
	for (i = 0; i < row; i++)//�����ж�
	{
		int countX = 0;
		int count0 = 0;
		for (j = 0; j < col; j++)
		{
			if (board[i][j] == 'X')
			{
				countX++;
			}
			if (board[i][j] == '0')
			{
				count0++;
			}
			if (countX == 3)
			{
				printf("���Ӯ\n");
				return 1;
			}
			if (count0 == 3)
			{
				printf("����Ӯ\n");
				return 2;
			}
		}
	}
	for (j = 0; j < col; j++)//�����ж�
	{
		int countX = 0;
		int count0 = 0;
		for (i = 0; i < row; i++)
		{
			if (board[i][j] == 'X')
			{
				countX++;
			}
			if (board[i][j] == '0')
			{
				count0++;
			}
			if (countX == 3)
			{
				printf("���Ӯ\n");
				return 1;
			}
			if (count0 == 3)
			{
				printf("����Ӯ\n");
				return 2;
			}
		}
	}
	if(board[0][0]== 'X'&&board[1][1]=='X' && board[2][2]=='X')
	{
		printf("���Ӯ\n");
		return 1;
	}
	if (board[0][0] == '0'&&board[1][1] == '0' && board[2][2] == '0')
	{
		printf("����Ӯ\n");
		return 2;
	}
	for (i = 0; i < row; i++)
	{
		int count = 0;
		for (j = 0; j < col; j++)
		{
			if (board[i][j] != 0)
			{
				count++;
			}
			if (count == 9)
			{
				return 3;
				printf("ƽ��\n");
			}
		}
	}
	return 0;
}